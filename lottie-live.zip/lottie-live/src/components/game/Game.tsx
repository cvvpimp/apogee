import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { CHIP_VALUES } from "@/lib/money";
import { handValue } from "@/lib/blackjack/engine";
import { useGame } from "@/lib/blackjack/store";
import { formatMoney } from "@/lib/utils";
import { Dealer } from "./Dealer";
import { DealerCam } from "./DealerCam";
import { Hud } from "./Hud";
import { PlayingCard } from "./PlayingCard";
import { Rules } from "./Rules";
import { StartScreen } from "./StartScreen";
import { Tray } from "./Tray";

export function Game() {
  const seated = useGame((s) => s.seated);
  const hydrate = useGame((s) => s.hydrate);
  const setChip = useGame((s) => s.setChip);
  const addChip = useGame((s) => s.addChip);
  const deal = useGame((s) => s.deal);
  const hit = useGame((s) => s.hit);
  const stand = useGame((s) => s.stand);
  const bankroll = useGame((s) => s.bankroll);
  const bet = useGame((s) => s.bet);
  const phase = useGame((s) => s.phase);
  const rebuy = useGame((s) => s.rebuy);
  const toasts = useGame((s) => s.toasts);
  const player = useGame((s) => s.player);
  const dealer = useGame((s) => s.dealer);
  const holeHidden = useGame((s) => s.holeHidden);
  const clip = useGame((s) => s.clip);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!useGame.getState().seated) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        const s = useGame.getState();
        if (s.phase === "betting") deal();
        else if (s.phase === "player") stand();
      }
      if (e.key === "h" || e.key === "H") hit();
      const idx = ["Digit1", "Digit2", "Digit3", "Digit4", "Digit5"].indexOf(e.code);
      if (idx >= 0) {
        const chip = CHIP_VALUES[idx];
        if (chip) {
          setChip(chip);
          addChip();
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [addChip, deal, hit, setChip, stand]);

  if (!seated) {
    return <StartScreen />;
  }

  const playerTotal = player.length ? handValue(player).total : null;
  const dealerTotal =
    dealer.length && !holeHidden ? handValue(dealer).total : dealer.length ? handValue(dealer.slice(0, 1)).total : null;
  const busted = bankroll <= 0 && bet <= 0 && phase === "betting";
  const clipLabel = clip === "shuffle" ? "Shuffling the shoe" : clip === "deal" ? "Dealing" : null;

  return (
    <div className="relative flex h-dvh flex-col overflow-hidden bg-ink text-cream">
      <DealerCam />
      <div className="absolute inset-0 bg-gradient-to-t from-ink/95 via-ink/10 to-ink/40" />

      <Hud />

      {clipLabel ? (
        <div className="pointer-events-none absolute inset-x-0 top-16 z-20 flex justify-center">
          <p className="rounded-full bg-ink/70 px-3 py-1 font-table text-[10px] tracking-[0.28em] text-line uppercase">
            {clipLabel}
          </p>
        </div>
      ) : null}

      <div className="relative z-10 flex min-h-0 flex-1 flex-col items-center justify-center gap-3 px-3 pt-16 pb-1">
        {dealer.length > 0 || player.length > 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-[22px] bg-ink/50 px-4 py-3 shadow-[inset_0_0_0_1px_rgba(232,220,196,0.1)]">
            <div className="flex flex-col items-center gap-1">
              <p className="font-table text-[10px] tracking-[0.24em] text-line/80 uppercase">
                Dealer {dealerTotal != null ? dealerTotal : ""}
              </p>
              <div className="flex gap-1.5">
                {dealer.map((c, i) => (
                  <PlayingCard
                    key={c.id}
                    card={c}
                    hidden={holeHidden && i === 1}
                    delay={i * 120}
                  />
                ))}
              </div>
            </div>
            <div className="flex flex-col items-center gap-1">
              <div className="flex gap-1.5">
                {player.map((c, i) => (
                  <PlayingCard key={c.id} card={c} delay={i * 120} />
                ))}
              </div>
              {playerTotal != null ? (
                <p className="font-table text-sm tracking-[0.18em] text-cream uppercase">
                  You {playerTotal}
                </p>
              ) : null}
            </div>
          </div>
        ) : null}
        {bet > 0 ? (
          <div className="rounded-full bg-ink/70 px-3 py-1 font-table text-sm tracking-wide text-line tabular-nums">
            Bet {formatMoney(bet)}
          </div>
        ) : null}
      </div>

      <div className="relative z-20 flex flex-col gap-2 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:p-4">
        <Dealer />
        <Tray />
      </div>

      <div className="pointer-events-none absolute inset-x-0 top-24 z-40 flex justify-center">
        <div className="flex flex-col items-center gap-2">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={
                t.tone === "win"
                  ? "rounded-full bg-win px-3 py-1 font-table text-sm font-semibold tracking-wide text-ink"
                  : t.tone === "lose"
                    ? "rounded-full bg-lose px-3 py-1 font-table text-sm font-semibold tracking-wide text-cream"
                    : "rounded-full bg-cream px-3 py-1 font-table text-sm font-semibold tracking-wide text-ink"
              }
            >
              {t.text}
            </div>
          ))}
        </div>
      </div>

      {busted ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/75 p-4">
          <div className="w-full max-w-sm rounded-[24px] bg-rail p-6 text-center">
            <h2 className="font-display text-2xl">Rail's empty</h2>
            <p className="mt-2 text-sm text-muted">
              Lottie will mark you another {formatMoney(1000)}.
            </p>
            <Button className="mt-5 w-full" onClick={rebuy}>
              Take the marker
            </Button>
          </div>
        </div>
      ) : null}

      <Rules />
    </div>
  );
}
